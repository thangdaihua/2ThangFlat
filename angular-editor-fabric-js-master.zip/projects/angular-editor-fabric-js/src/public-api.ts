/*
 * Public API Surface of angular-editor-fabric-js
 */

export * from './lib/angular-editor-fabric-js.component';
export * from './lib/angular-editor-fabric-js.module';
